import React, { useContext, useEffect, useState } from "react";

import PostCard from "../components/PostCard";
import { readPost } from "../utility/crudUtility";
import { CategContext } from "../context/CategContext";

export const Posts = () => {
  const { categories } = useContext(CategContext);
  const [posts, setPosts] = useState([]);
  useEffect(() => {
    readPost(setPosts);
  }, []);
  posts.length > 0 && console.log(posts);

  return (
    <>
      <div className="page">
        {/* Radio Buttons Section */}
        <div
          style={{
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
            gap: "10px", // Spacing between radio buttons
            marginBottom: "20px", // Spacing below the radio buttons
          }}
        >
          {categories &&
            categories.map((obj) => (
              <label>
                <input type="radio" name="filter" value="option1" /> {obj.name}
              </label>
            ))}
        </div>

        {/* Posts Section */}
        <div
          style={{
            display: "flex",
            justifyContent: "center", // Center items horizontally
            alignItems: "center", // Center items vertically
            flexWrap: "wrap", // Allow wrapping of the cards
            gap: "10px", // Add spacing between cards (optional)
          }}
        >
          {posts?.length > 0 &&
            posts.map((key) => (
              <PostCard
                url={key.photo.url}
                name={key.displayName}
                username={key.author}
                key={key.photo.id}
                story={key.story}
              />
            ))}
        </div>
      </div>
    </>
  );
};
