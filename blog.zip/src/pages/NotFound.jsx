import React from 'react'

export const NotFound = () => {
  return (
    <div className='page'>
      default NotFound
    </div>
  )
}


