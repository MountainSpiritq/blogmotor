import React from 'react'


export const Admin = () => {
  return (
    <div className='page'>
      default Admin
    </div>
  )
}

