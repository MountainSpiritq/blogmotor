//import { initializeApp } from "firebase/app";

export const firebaseConfig = {
  apiKey: "AIzaSyCdnZaBhkcaxwT6Hd3YPnflNI_uCd6qbOg",
  authDomain: "blog-d3200.firebaseapp.com",
  projectId: "blog-d3200",
  storageBucket: "blog-d3200.firebasestorage.app",
  messagingSenderId: "61088167467",
  appId: "1:61088167467:web:bcb44b4b5933696feadc6e",
};

